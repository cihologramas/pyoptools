from definitions import *

__all__=["inf_vect",]
