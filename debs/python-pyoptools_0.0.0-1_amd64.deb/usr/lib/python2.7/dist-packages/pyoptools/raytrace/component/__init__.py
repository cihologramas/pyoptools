'''
Module containing the component Class definition
'''


from component import *
__all__=["Component"]
